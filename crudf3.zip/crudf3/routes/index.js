
  /*
    MIT License
    
    Copyright (c) 2025 Christian I. Cabrera || XianFire Framework
    Mindoro State University - Philippines

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    */
    
import express from "express";
const router = express.Router();


import { homePage } from "../controllers/homeController.js";
router.get("/", homePage);

import { loginPage, registerPage, forgotPasswordPage, dashboardPage, loginUser, registerUser, logoutUser } from "../controllers/authController.js";
router.get("/login", loginPage);
router.post("/login", loginUser);
router.get("/register", registerPage);
router.post("/register", registerUser);
router.get("/forgot-password", forgotPasswordPage);
router.get("/dashboard", dashboardPage);
router.get("/logout", logoutUser);


import subject from "../controllers/subject.js"; 
router.post("/subjects", subject.insert);
router.get("/subjects", subject.all);
router.get("/subjects/:id", subject.one);


import { course } from "../controllers/course.js";
import { department } from "../controllers/department.js";
import { enrollment } from "../controllers/enrollment.js";
import { instructorcontroller } from "../controllers/instructorcontroller.js";
import { studentcontroller } from "../controllers/studentcontroller.js";


router.get("/courses", course.all);
router.get("/courses/:id", course.one);
router.post("/courses", course.insert);


router.get("/departments", department.all);
router.get("/departments/:id", department.one);
router.post("/departments", department.insert);


router.get("/enrollments", enrollment.all);
router.get("/enrollments/:id", enrollment.one);
router.post("/enrollments", enrollment.insert);


router.get("/instructors", instructorcontroller.all);
router.get("/instructors/:id", instructorcontroller.one);
router.post("/instructors", instructorcontroller.insert);


router.get("/students", studentcontroller.all);
router.get("/students/:id", studentcontroller.one);
router.post("/students", studentcontroller.insert);

export default router;